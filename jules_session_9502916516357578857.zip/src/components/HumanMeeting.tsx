"use client";

import React, { useState } from "react";
import { trackEvent } from "@/lib/analytics";

export default function HumanMeeting() {
  const [showCalendlyModal, setShowCalendlyModal] = useState(false);

  const handleOpenCalendly = () => {
    trackEvent({ name: "booking_initiated", source: "hero" });
    trackEvent({ name: "calendly_opened" });
    setShowCalendlyModal(true);
  };

  return (
    <section id="human-meeting" className="py-24 px-6 bg-[#f7f4ee] relative overflow-hidden">
      {/* Decorative Gold Accent */}
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-40 h-[1px] bg-gradient-to-r from-transparent via-[#c5a059] to-transparent" />

      <div className="max-w-3xl mx-auto text-center space-y-8">
        <div className="text-xs uppercase tracking-widest text-[#1d3b45]/70 font-light">
          מפגש אנושי • HUMAN MEETING
        </div>

        {/* Copy */}
        <h2 className="text-2xl sm:text-4xl font-serif text-[#2c2a29] leading-snug font-normal max-w-2xl mx-auto">
          &quot;אם כמה דקות כאן החזירו לך קצת אוויר, החוויה האמיתית ממתינה במפגש אנושי, פנים אל פנים.&quot;
        </h2>

        <p className="text-base sm:text-lg text-[#615a56] font-light max-w-xl mx-auto leading-relaxed">
          מפגש אישי ואינטימי בקליניקה. מקום שבו האמנות, הגוף והרצון שלך נפגשים ללא שיפוט או מסכות.
        </p>

        {/* Primary Booking Button */}
        <div className="pt-4">
          <button
            onClick={handleOpenCalendly}
            className="px-10 py-5 rounded-full bg-[#1d3b45] text-[#fcfaf7] font-light text-lg sm:text-xl hover:bg-[#2e5361] hover:shadow-lg transition-all duration-300 border border-[#1d3b45] cursor-pointer"
          >
            תיאום מפגש אישי בקליניקה
          </button>
        </div>

        {/* Inline Calendly Widget Embed Area */}
        <div className="mt-12 p-6 rounded-2xl bg-[#fcfaf7] border border-[#c5a059]/25 shadow-sm text-center">
          <p className="text-sm text-[#615a56] font-light mb-4">
            בחרי תאריך ושעה הנוחים לך ביומן המפגשים הקרוב:
          </p>

          {/* Embedded Calendly iFrame Container */}
          <div className="w-full h-[600px] rounded-xl overflow-hidden border border-[#c5a059]/20 bg-white">
            <iframe
              src="https://calendly.com/?embed_domain=joyfulness-clinic.co.il&embed_type=Inline"
              width="100%"
              height="100%"
              frameBorder="0"
              title="Calendly Booking Widget"
              className="w-full h-full"
            />
          </div>
        </div>
      </div>

      {/* Modal Fallback / Expanded Calendly Viewer */}
      {showCalendlyModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-sm animate-fadeIn">
          <div className="bg-[#fcfaf7] border border-[#c5a059] rounded-2xl p-6 max-w-3xl w-full max-h-[90vh] flex flex-col relative shadow-2xl">
            <div className="flex justify-between items-center mb-4 pb-2 border-b border-[#c5a059]/20">
              <h3 className="text-xl font-serif text-[#2c2a29]">
                תיאום מפגש אישי - קליניקת ג&apos;וייפולנס
              </h3>
              <button
                onClick={() => setShowCalendlyModal(false)}
                className="text-[#2c2a29] hover:text-[#c5a059] text-2xl font-light cursor-pointer px-2"
              >
                ✕
              </button>
            </div>
            <div className="flex-1 w-full h-[550px]">
              <iframe
                src="https://calendly.com/?embed_domain=joyfulness-clinic.co.il&embed_type=Inline"
                width="100%"
                height="100%"
                frameBorder="0"
                title="Calendly Modal Booking"
                className="w-full h-full rounded-xl"
              />
            </div>
          </div>
        </div>
      )}
    </section>
  );
}
