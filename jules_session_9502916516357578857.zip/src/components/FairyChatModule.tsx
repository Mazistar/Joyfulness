"use client";

import React, { useState, useRef, useEffect } from "react";
import { trackEvent } from "@/lib/analytics";

interface Message {
  id: string;
  role: "user" | "assistant";
  content: string;
}

export default function FairyChatModule() {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: "welcome-1",
      role: "assistant",
      content:
        "שלום לך. זו נישה של שקט עבורך. מקום להניח את הכל בצד לרגע.\n\nאיפה את מרגישה את העייפות או הרצון שלך ממש עכשיו?",
    },
  ]);
  const [input, setInput] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [turn, setTurn] = useState(1);
  const [isCompleted, setIsCompleted] = useState(false);

  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages, isLoading]);

  const handleSendMessage = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    const userText = input.trim();
    if (!userText || isLoading || isCompleted) return;

    const userMessage: Message = {
      id: `user-${Date.now()}`,
      role: "user",
      content: userText,
    };

    const newMessages = [...messages, userMessage];
    setMessages(newMessages);
    setInput("");
    setIsLoading(true);

    if (turn === 1) {
      trackEvent({ name: "fairy_chat_started", initialMessageLength: userText.length });
    }
    trackEvent({ name: "fairy_chat_message_sent", turn });

    try {
      const response = await fetch("/api/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          messages: newMessages.map((m) => ({ role: m.role, content: m.content })),
          turn,
        }),
      });

      const data = await response.json();

      const assistantMessage: Message = {
        id: `assistant-${Date.now()}`,
        role: "assistant",
        content: data.message || "אני איתך, מקשיבה בנחת.",
      };

      setMessages((prev) => [...prev, assistantMessage]);

      if (data.isFinalTurn || turn >= 4) {
        setIsCompleted(true);
        trackEvent({ name: "fairy_chat_completed", totalTurns: turn });
      } else {
        setTurn((prev) => prev + 1);
      }
    } catch (error) {
      console.error("Failed to fetch response:", error);
      const fallbackMsg: Message = {
        id: `assistant-err-${Date.now()}`,
        role: "assistant",
        content:
          "הנשימה נזקקת לעוד רגע. אני איתך. ספרי לי עוד ממה שמבקש לצאת עכשיו.",
      };
      setMessages((prev) => [...prev, fallbackMsg]);
    } finally {
      setIsLoading(false);
    }
  };

  const handleBookingRedirect = () => {
    trackEvent({ name: "booking_initiated", source: "chat_completion" });
    const humanSec = document.getElementById("human-meeting");
    if (humanSec) {
      humanSec.scrollIntoView({ behavior: "smooth" });
    }
  };

  return (
    <section id="fairy-module" className="py-20 px-4 sm:px-6 bg-[#fcfaf7]">
      <div className="max-w-2xl mx-auto">
        {/* Section Title & Doorway Styling */}
        <div className="text-center mb-8 space-y-3">
          <span className="inline-block text-xs uppercase tracking-widest text-[#c5a059] font-medium px-3 py-1 rounded-full border border-[#c5a059]/30 bg-[#f5f0e8]/50">
            נשימה ראשונה • FIRST BREATH
          </span>
          <h2 className="text-2xl sm:text-3xl font-serif text-[#2c2a29] font-normal">
            מפגש הקשבה אישי
          </h2>
          <p className="text-sm sm:text-base text-[#615a56] font-light max-w-lg mx-auto">
            פתח צנוע ואינטימי להתבוננות פנימה. 3–4 גשרים של שיחה ללא שיפוט.
          </p>
        </div>

        {/* Chat Window Container */}
        <div className="bg-[#f5f0e8]/90 backdrop-blur-sm border border-[#c5a059]/30 rounded-2xl shadow-lg p-4 sm:p-8 flex flex-col min-h-[480px] max-h-[650px] relative transition-all duration-300">
          {/* Gold Accent Corner */}
          <div className="absolute top-0 right-0 w-16 h-16 pointer-events-none opacity-40 border-t-2 border-r-2 border-[#c5a059] rounded-tr-2xl" />
          <div className="absolute bottom-0 left-0 w-16 h-16 pointer-events-none opacity-40 border-b-2 border-l-2 border-[#c5a059] rounded-bl-2xl" />

          {/* Messages Stream */}
          <div className="flex-1 overflow-y-auto space-y-6 pr-2 pl-2 mb-4 scroll-smooth">
            {messages.map((msg) => (
              <div
                key={msg.id}
                className={`flex flex-col ${
                  msg.role === "user" ? "items-end" : "items-start"
                }`}
              >
                <div
                  className={`max-w-[88%] sm:max-w-[80%] p-4 sm:p-5 rounded-2xl leading-relaxed whitespace-pre-wrap text-base sm:text-lg font-light transition-all ${
                    msg.role === "user"
                      ? "bg-[#1d3b45] text-[#fcfaf7] rounded-br-none shadow-sm"
                      : "bg-[#fcfaf7] text-[#2c2a29] border border-[#c5a059]/20 rounded-bl-none shadow-sm font-serif"
                  }`}
                >
                  {msg.content}
                </div>
              </div>
            ))}

            {isLoading && (
              <div className="flex items-start">
                <div className="bg-[#fcfaf7] text-[#615a56] px-5 py-3 rounded-2xl rounded-bl-none border border-[#c5a059]/20 text-sm font-light flex items-center gap-2">
                  <span className="w-2 h-2 rounded-full bg-[#c5a059] animate-ping" />
                  <span>מקשיבה ונושמת איתך...</span>
                </div>
              </div>
            )}

            <div ref={messagesEndRef} />
          </div>

          {/* Chat Completion WOW Moment Banner */}
          {isCompleted && (
            <div className="my-4 p-5 rounded-xl bg-gradient-to-r from-[#1d3b45]/10 via-[#c5a059]/15 to-[#1d3b45]/10 border border-[#c5a059]/40 text-center space-y-4 animate-fadeIn">
              <p className="text-sm sm:text-base text-[#2c2a29] font-medium leading-relaxed">
                &quot;החוויה האמיתית ממתינה במפגש אנושי, פנים אל פנים.&quot;
              </p>
              <button
                onClick={handleBookingRedirect}
                className="w-full sm:w-auto px-6 py-3 rounded-full bg-[#1d3b45] text-[#fcfaf7] text-sm sm:text-base font-light hover:bg-[#2e5361] transition-all shadow-md"
              >
                לקביעת מפגש אנושי בקליניקה ←
              </button>
            </div>
          )}

          {/* Text Input Area */}
          {!isCompleted && (
            <form onSubmit={handleSendMessage} className="relative mt-2">
              <input
                type="text"
                value={input}
                onChange={(e) => setInput(e.target.value)}
                disabled={isLoading}
                placeholder="איפה את מרגישה את העייפות או הרצון שלך ממש עכשיו?"
                className="w-full py-4 pr-5 pl-14 rounded-xl border border-[#c5a059]/40 bg-[#fcfaf7] text-[#2c2a29] placeholder-[#615a56]/60 focus:outline-none focus:border-[#c5a059] focus:ring-1 focus:ring-[#c5a059] font-light text-base transition-all"
              />
              <button
                type="submit"
                disabled={!input.trim() || isLoading}
                className="absolute left-2 top-1/2 -translate-y-1/2 px-4 py-2 rounded-lg bg-[#c5a059] text-[#fcfaf7] font-light text-sm hover:bg-[#b38e47] disabled:opacity-40 transition-all cursor-pointer"
              >
                שליחה
              </button>
            </form>
          )}
        </div>
      </div>
    </section>
  );
}
