"use client";

import React from "react";

export default function CoreMessage() {
  return (
    <section className="py-20 px-6 bg-[#f7f4ee] border-y border-[#c5a059]/15 relative">
      <div className="max-w-3xl mx-auto text-center space-y-12">
        {/* Section Heading Tag */}
        <div className="text-xs uppercase tracking-widest text-[#1d3b45]/60 font-light">
          המצפן • THE COMPASS
        </div>

        {/* Poetic Short Breathing Lines */}
        <div className="space-y-8 text-xl sm:text-2xl md:text-3xl font-serif leading-relaxed text-[#2c2a29] font-light">
          <p className="opacity-90 transition-opacity">
            במשך שנים למדת לבחור בשייכות, בתפקוד ובציפיות חיצוניות.
          </p>

          <p className="text-[#1d3b45] italic font-normal py-2">
            הפסקת לשאול:{" "}
            <span className="underline decoration-[#c5a059]/40 underline-offset-8">
              מה בא לי? מה מרגש אותי? מה נכון לי?
            </span>
          </p>

          <p className="opacity-90">
            הקליניקה לא באה לתקן אותך או ללמד אותך שיטות חדשות.
          </p>

          <p className="text-[#2c2a29] font-medium leading-relaxed pt-2">
            היא מחזירה לך את הרשות להיות נאמנה לעצמך—
            <span className="block text-[#1d3b45] sm:inline mt-1 sm:mt-0">
              ונשענת על העונג והחיות כמצפן הבלעדי.
            </span>
          </p>
        </div>

        {/* Delicate Kintsugi Line Accent */}
        <div className="w-16 h-[1px] bg-[#c5a059] mx-auto opacity-50" />
      </div>
    </section>
  );
}
