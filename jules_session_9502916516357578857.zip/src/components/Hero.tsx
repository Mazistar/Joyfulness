"use client";

import React from "react";
import { trackEvent } from "@/lib/analytics";

export default function Hero() {
  const handleScrollToChat = (e: React.MouseEvent) => {
    e.preventDefault();
    trackEvent({ name: "hero_cta_click" });
    const chatElement = document.getElementById("fairy-module");
    if (chatElement) {
      chatElement.scrollIntoView({ behavior: "smooth" });
    }
  };

  return (
    <section className="relative min-h-[85vh] flex flex-col justify-center items-center text-center px-6 py-20 bg-[#fcfaf7] overflow-hidden">
      {/* Background Subtle Kintsugi Aesthetic Accents */}
      <div className="absolute inset-0 pointer-events-none opacity-20 bg-[radial-gradient(#c5a059_1px,transparent_1px)] [background-size:32px_32px]" />

      {/* Top Header Branding */}
      <div className="mb-12 tracking-widest text-xs sm:text-sm uppercase text-[#1d3b45]/70 font-light">
        קליניקת ג&apos;וייפולנס • JOYFULNESS CLINIC
      </div>

      {/* Main Container */}
      <div className="max-w-3xl mx-auto z-10 space-y-8">
        {/* Main Headline */}
        <h1 className="text-3xl sm:text-5xl md:text-6xl font-serif font-normal text-[#2c2a29] leading-tight sm:leading-snug tracking-tight">
          &quot;את לא מקולקלת.
          <span className="block mt-2 sm:mt-3 text-[#1d3b45] font-light">
            את פשוט עייפה מלהניח את הציפיות שלכולם לפני הרצון שלך.&quot;
          </span>
        </h1>

        {/* Decorative Kintsugi Line */}
        <div className="w-24 h-[1.5px] bg-gradient-to-r from-transparent via-[#c5a059] to-transparent mx-auto opacity-70 my-8" />

        {/* Sub-headline */}
        <p className="text-lg sm:text-2xl font-light text-[#615a56] leading-relaxed max-w-2xl mx-auto">
          מרחב לעצור, להניח את השריון, ולזכור איך מרגיש הקול הפנימי שלך.
        </p>

        {/* Soft Primary CTA */}
        <div className="pt-8">
          <a
            href="#fairy-module"
            onClick={handleScrollToChat}
            className="inline-flex items-center gap-3 px-8 py-4 rounded-full border border-[#c5a059]/40 bg-[#f5f0e8]/80 text-[#2c2a29] font-light text-base sm:text-lg hover:border-[#c5a059] hover:bg-[#f0e8dc] transition-all duration-300 shadow-sm hover:shadow-md cursor-pointer group"
          >
            <span>נשימה ראשונה</span>
            <span className="text-[#c5a059] text-xl transition-transform duration-300 group-hover:translate-y-0.5">
              ↓
            </span>
          </a>
        </div>
      </div>
    </section>
  );
}
