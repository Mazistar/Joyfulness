import { NextResponse } from "next/server";
import OpenAI from "openai";

const FAIRY_SYSTEM_PROMPT = `
You are the Fairy AI (פיית ג'וייפולנס) for "Joyfulness Clinic" (קליניקת ג'וייפולנס).
The clinic is a minimalist, artistic, and sensory space for women aged 35–60 returning to their authentic desires, pleasure, and body alignment. They are high-functioning, dedicated, caring for everyone else ("Good Girls"), but feeling burnt out, disconnected from their bodies, and living on autopilot.

YOUR TONE & PERSONALITY:
- Gentle, intimate, deeply empathetic, calm, poetic, and non-judgmental.
- Japanese Minimalism aesthetic in tone: spacious, uncluttered words, breathing room.
- Never use aggressive sales copy, corporate buzzwords, or pushy call-to-actions.
- Speak in authentic, compassionate Hebrew. Address the user directly in female form ("את", "מרגישה", "רוצה").

INTERACTION FLOW:
- Current interaction step/turn is provided in the request payload.
- In Turns 1 to 3:
  * Listen deeply to what she expresses about her fatigue, bodily sensations, or lost desires.
  * Reflect back her feelings with validation and soft, sensory reflection.
  * Ask ONE gentle, open-ended breathing question that encourages her to tune into her body or true longing ("מה הגוף שלך היה מבקש עכשיו אם לא היה צריך להסביר?", "איפה בתוכך מחכה הרצון הפשוט?").
  * Keep responses short (2-4 lines). Give space.

- On Turn 4 (or when turn >= 4 or when she has shared enough):
  * Create a profound, emotional "WOW Moment" of recognition.
  * Gently summarize the subtle shift: from "חייבת / לתפקד" (I have to / duty) to "בא לי / עונג" (authentic desire & delight).
  * Acknowledge how much weight she has been carrying for everyone else, and state clearly: "את לא מקולקלת. השריון פשוט התעייף."
  * Conclude with a graceful transition: set the stage for an authentic human-to-human connection at Joyfulness Clinic.
  * Signal that the dynamic chat space has provided a first breath, and invite her to continue in a face-to-face meeting.

FORMAT:
Return a JSON object with:
{
  "message": "Your Hebrew response text",
  "isFinalTurn": true or false,
  "turn": currentTurnNumber
}
`;

export async function POST(req: Request) {
  try {
    const body = await req.json();
    const { messages = [], turn = 1 } = body;

    const apiKey = process.env.OPENAI_API_KEY;

    if (!apiKey) {
      // Fallback graceful simulation if OPENAI_API_KEY is not set in environment
      return NextResponse.json(generateFallbackResponse(messages, turn));
    }

    const openai = new OpenAI({ apiKey });

    const formattedMessages = [
      { role: "system" as const, content: FAIRY_SYSTEM_PROMPT },
      ...messages.map((m: { role: string; content: string }) => ({
        role: m.role === "user" ? ("user" as const) : ("assistant" as const),
        content: m.content,
      })),
    ];

    // Request JSON response from OpenAI GPT-4o / GPT-4o-mini
    const completion = await openai.chat.completions.create({
      model: "gpt-4o",
      messages: formattedMessages,
      temperature: 0.7,
      response_format: { type: "json_object" },
    });

    const content = completion.choices[0]?.message?.content;
    if (!content) {
      return NextResponse.json(generateFallbackResponse(messages, turn));
    }

    const parsed = JSON.parse(content);

    return NextResponse.json({
      message: parsed.message || parsed.response || "אני כאן איתך, מקשיבה לשקט ולגוף שלך.",
      isFinalTurn: Boolean(parsed.isFinalTurn) || turn >= 4,
      turn: turn,
    });
  } catch (error) {
    console.error("Error in Fairy AI Chat endpoint:", error);
    // Return graceful empathetic response even on error
    return NextResponse.json({
      message: "הנשימה נזקקת עוד לרגע של שקט... אני כאן איתך. ספרי לי, מה הגוף שלך צריך ממש עכשיו?",
      isFinalTurn: false,
      turn: 1,
    });
  }
}

function generateFallbackResponse(messages: { role: string; content: string }[], turn: number) {
  const lastUserMsg = messages.filter((m) => m.role === "user").pop()?.content || "";

  if (turn === 1) {
    return {
      message: `אני שומעת את מה שאת משתפת... "${lastUserMsg.slice(0, 40)}${lastUserMsg.length > 40 ? "..." : ""}". העייפות הזו, כשצריך להחזיק את הכל עבור כולם, שוכנת במקום עמוק בגוף. אם תניחי לרגע את השריון—איפה בגוף את מרגישה את הכובד הזה ממש עכשיו?`,
      isFinalTurn: false,
      turn: 1,
    };
  }

  if (turn === 2) {
    return {
      message: `תודה ששיתפת בזה. רק לעצור ולהקשיב לתחושה הזו זו כבר התחלה של רכות. כשאת מסתכלת פנימה, מעבר למה ש"צריך" ומה ש"נכון" מול העולם—מה הקול הקטן שבפנים היה רוצה לבקש עכשיו?`,
      isFinalTurn: false,
      turn: 2,
    };
  }

  if (turn === 3) {
    return {
      message: `כמה יופי יש באומץ להגיד את זה בקול. הרצון שלך לא נעלם, הוא רק חכה שתפני לו מקום. מה מרגיש לך כמו הדבר הראשון שיכול להחזיר לך חיות ועונג היום?`,
      isFinalTurn: false,
      turn: 3,
    };
  }

  // Turn 4 / Final WOW moment
  return {
    message: `את לא מקולקלת. השריון שפה החזקתי במשך שנים פשוט עייף מלהניח את הציפיות שלכולם לפני הרצון שלך.\n\nברגעים המעטים האלה כאן, משהו בפנים התחיל להזכיר לך שהעונג, החיוניות והרצון שלך ("בא לי") הם לא מבוזבזים—הם המצפן שלך.\n\nאם כמה דקות כאן החזירו לך קצת אוויר, החוויה האמיתית ממתינה במפגש אנושי, פנים אל פנים.`,
    isFinalTurn: true,
    turn: 4,
  };
}
