import type { Metadata } from "next";
import { Heebo, Frank_Ruhl_Libre } from "next/font/google";
import "./globals.css";

const heebo = Heebo({
  subsets: ["hebrew", "latin"],
  variable: "--font-heebo",
  weight: ["300", "400", "500", "600"],
  display: "swap",
});

const frankRuhl = Frank_Ruhl_Libre({
  subsets: ["hebrew", "latin"],
  variable: "--font-frank-ruhl",
  weight: ["300", "400", "500", "700"],
  display: "swap",
});

export const metadata: Metadata = {
  title: "קליניקת ג'וייפולנס | Joyfulness Clinic",
  description: "מרחב מינימליסטי ואמנותי לנשים החוזרות לרצון, לעונג ולחיבור לגוף.",
  keywords: ["קליניקת ג'וייפולנס", "Joyfulness Clinic", "חיבור לגוף", "עונג", "תשוקה", "הקשבה פנימית"],
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html
      lang="he"
      dir="rtl"
      className={`${heebo.variable} ${frankRuhl.variable} h-full antialiased scroll-smooth`}
    >
      <body className="min-h-full flex flex-col bg-[#fcfaf7] text-[#2c2a29] selection:bg-[#e6d3a3] selection:text-[#1d3b45]">
        {children}
      </body>
    </html>
  );
}
