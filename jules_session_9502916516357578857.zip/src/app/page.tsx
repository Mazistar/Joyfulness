import Hero from "@/components/Hero";
import CoreMessage from "@/components/CoreMessage";
import FairyChatModule from "@/components/FairyChatModule";
import HumanMeeting from "@/components/HumanMeeting";

export default function Home() {
  return (
    <main className="min-h-screen flex flex-col bg-[#fcfaf7] text-[#2c2a29] selection:bg-[#e6d3a3] selection:text-[#1d3b45]">
      {/* Section 1: Hero Section (The Mirror) */}
      <Hero />

      {/* Section 2: Core Message (From "I Have To" to "Ba Li") */}
      <CoreMessage />

      {/* Section 3: Interactive Fairy Module (Embedded AI Chat Window) */}
      <FairyChatModule />

      {/* Section 4: Invitation to Human Meeting */}
      <HumanMeeting />

      {/* Footer */}
      <footer className="py-12 px-6 border-t border-[#c5a059]/20 text-center text-xs sm:text-sm text-[#615a56] font-light bg-[#f7f4ee]">
        <div className="max-w-3xl mx-auto space-y-3">
          <p className="font-serif text-[#1d3b45] text-base">
            קליניקת ג&apos;וייפולנס • Joyfulness Clinic
          </p>
          <p>
            מרחב מינימליסטי, אמנותי ותחושתי לנשים החוזרות לרצון, לעונג ולחיבור לגוף.
          </p>
          <div className="pt-2 text-[11px] text-[#615a56]/70">
            © {new Date().getFullYear()} Joyfulness Clinic. כל הזכויות שמורות.
          </div>
        </div>
      </footer>
    </main>
  );
}
