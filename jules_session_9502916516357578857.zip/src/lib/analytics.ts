/**
 * Minimalist Analytics & Event Tracking for Joyfulness Clinic
 * Tracks engagement with the interactive Fairy module and conversion to Calendly meeting bookings.
 */

export type AnalyticsEvent =
  | { name: "hero_cta_click" }
  | { name: "fairy_chat_started"; initialMessageLength: number }
  | { name: "fairy_chat_message_sent"; turn: number }
  | { name: "fairy_chat_completed"; totalTurns: number }
  | { name: "booking_initiated"; source: "hero" | "chat_completion" | "footer" }
  | { name: "calendly_opened" };

type GtagFunction = (...args: unknown[]) => void;

export function trackEvent(event: AnalyticsEvent) {
  try {
    const timestamp = new Date().toISOString();
    const payload = {
      ...event,
      timestamp,
      url: typeof window !== "undefined" ? window.location.href : "",
    };

    // Log to console for development visibility
    if (process.env.NODE_ENV !== "production") {
      console.log("[Analytics Event]:", payload);
    }

    // Support window.gtag if integrated in future
    if (typeof window !== "undefined" && (window as unknown as { gtag?: GtagFunction }).gtag) {
      (window as unknown as { gtag: GtagFunction }).gtag("event", event.name, payload);
    }

    // Persist in localStorage for conversion metrics review
    if (typeof window !== "undefined" && window.localStorage) {
      const existing = JSON.parse(localStorage.getItem("joyfulness_analytics") || "[]");
      existing.push(payload);
      localStorage.setItem("joyfulness_analytics", JSON.stringify(existing.slice(-50)));
    }
  } catch (err) {
    console.warn("Analytics tracking error:", err);
  }
}
